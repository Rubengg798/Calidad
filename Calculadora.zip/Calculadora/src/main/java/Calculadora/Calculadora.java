package Calculadora;

/**
 *
 * @author javie
 */
public class Calculadora {
    
public double suma(double number1, double number2){
 return number1 + number2;
 }
 public double resta(double number1, double number2){
 return number1 - number2;
}
 public double multiplicacion(double number1, double number2) {
 return number1 * number2;
}
 public double division(double number1, double number2){
 return number1 / number2;
 }
 public double raizCuadrada1(double number1){
 return Math.sqrt(number1);
 }
 public double raizCuadrada2(double number2){
 return Math.sqrt(number2);
 }
 public double Logaritmo1(double number1){
 return Math.log(number1);
 }
 public double Logaritmo2(double number2){
 return Math.log(number2);
}
}

