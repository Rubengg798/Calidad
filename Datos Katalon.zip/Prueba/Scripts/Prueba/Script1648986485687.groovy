import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.chollometro.com/')

WebUI.click(findTestObject('Object Repository/Page_Chollos, ofertas y cupones  Chollometr_6aec4f/span_Aceptar todo'))

WebUI.click(findTestObject('Object Repository/Page_Chollos, ofertas y cupones  Chollometr_6aec4f/a_Monitor porttil Arzopa 17.3 Full HD 1920x_f4c9a2'))

WebUI.click(findTestObject('Object Repository/Page_Monitor porttil Arzopa 17.3 Full HD 19_8138d3/span_Ir al chollo'))

WebUI.switchToWindowTitle('Monitor portátil Arzopa 17.3\' Full HD 1920x1080P Ultra Slim Con Smart Cover para Xbox PS4 Switch PC Phone EU Negro - Monitor LED - Los mejores precios | Fnac')

WebUI.click(findTestObject('Object Repository/Page_Monitor porttil Arzopa 17.3 Full HD 19_eb6f1e/button_Aceptar todas las cookies'))

WebUI.click(findTestObject('Object Repository/Page_Monitor porttil Arzopa 17.3 Full HD 19_eb6f1e/div_0'))

WebUI.click(findTestObject('Object Repository/Page_Monitor porttil Arzopa 17.3 Full HD 19_eb6f1e/div_Tiendas_Header__tabs-icon Header__tabs-_0fb6f5'))

WebUI.setText(findTestObject('Object Repository/Page_Mi cuenta/input_Escribe un email para acceder o crear_d9789f'), 'ejemplocorreo@gmail.com')

