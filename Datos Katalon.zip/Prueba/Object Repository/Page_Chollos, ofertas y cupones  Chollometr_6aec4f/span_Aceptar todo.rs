<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Aceptar todo</name>
   <tag></tag>
   <elementGuidId>d75ac5a2-1e66-463e-a8b8-38be99e80fe0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/div[4]/div/div/div/div/div[2]/div[2]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.btn.btn--mode-primary.overflow--wrap-on</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn--mode-primary overflow--wrap-on</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Aceptar todo </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/div[@class=&quot;popover popover--oreo-message popover--visible zIndex--modal&quot;]/div[@class=&quot;will-transform aGrid--fixed flex height--max-100 aGrid-item--b-0 aGrid-item--r-0 aGrid-item--l-0 zIndex--modal seal--pointer-off space--mt-2&quot;]/div[@class=&quot;bg--color-white boxShadow--large width--all-12 flex&quot;]/div[@class=&quot;page2-center space--fromW3-h-3 flex&quot;]/div[@class=&quot;flex--fromW3 hAlign--all-c hAlign--fromW3-l space--h-4 space--fromW3-h-0 space--v-4 space--fromW3-t-6 space--fromW3-b-6 seal--pointer-on overflow--scrollY-raw&quot;]/div[2]/div[@class=&quot;flex flex--dir-col flex--fromW3-dir-row space--t-4&quot;]/button[@class=&quot;flex--grow-1 flex--fromW3-grow-0 width--fromW3-ctrl-m space--b-2 space--fromW3-b-0&quot;]/span[@class=&quot;btn btn--mode-primary overflow--wrap-on&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/div[4]/div/div/div/div/div[2]/div[2]/button/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Política sobre Cookies'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Política de Privacidad'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ajustes de cookies'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continuar sin aceptar'])[2]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Aceptar todo']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div[2]/div[2]/button/span</value>
   </webElementXpaths>
</WebElementEntity>
