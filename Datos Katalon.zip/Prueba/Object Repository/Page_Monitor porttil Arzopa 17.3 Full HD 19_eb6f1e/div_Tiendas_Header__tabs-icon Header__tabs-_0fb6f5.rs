<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Tiendas_Header__tabs-icon Header__tabs-_0fb6f5</name>
   <tag></tag>
   <elementGuidId>db74a5d6-83a7-47ec-ad19-9ab475d53c07</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[2]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.Header__tabs-icon.Header__tabs-icon--account</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Header__tabs-icon Header__tabs-icon--account</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-touchevents inbenta-bot--chrome-100&quot;]/body[1]/div[@class=&quot;non-legacy&quot;]/header[@class=&quot;Header Header--new js-Header&quot;]/div[@class=&quot;Header__main js-headerSearchView&quot;]/div[@class=&quot;Header__tabs-wrapper&quot;]/div[@class=&quot;Header__tabs js-HeaderTabs&quot;]/div[@class=&quot;Header__tabs-specific-wrapper&quot;]/div[@class=&quot;Header__tabs-item Header__tabs-item--account js-HeaderTabAccount&quot;]/a[@class=&quot;Header__tabs-link Header__tabs-link--account&quot;]/div[@class=&quot;Header__tabs-icon Header__tabs-icon--account&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/div</value>
   </webElementXpaths>
</WebElementEntity>
